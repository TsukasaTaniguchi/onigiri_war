#!/bin/bash
set -o verbose
empy onigiri_field.world.em > onigiri_field.world
